// TODO: CrowdyApp (start-up class)
// TODO: Set up the language, session and theme providers.
// TODO: Register the screens (Home, Detail, Directions, Settings) in the navigator.
