// TODO: SearchController (control)
// TODO: Rank venues against a search query.
