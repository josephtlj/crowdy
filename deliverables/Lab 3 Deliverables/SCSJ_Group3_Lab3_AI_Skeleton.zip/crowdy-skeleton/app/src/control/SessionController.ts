// TODO: SessionController (control, Observer)
// TODO: Hold the signed-in session and notify screens when it changes.
// TODO: Login, sign up, log out; prompt to merge guest saves on login.
