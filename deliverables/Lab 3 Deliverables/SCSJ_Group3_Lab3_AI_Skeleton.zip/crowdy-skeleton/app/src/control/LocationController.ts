// TODO: LocationController (control)
// TODO: Get the user's current location and watch for movement.
