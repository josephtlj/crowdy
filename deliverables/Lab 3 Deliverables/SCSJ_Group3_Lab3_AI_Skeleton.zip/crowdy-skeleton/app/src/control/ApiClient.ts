// TODO: ApiClient (control, Facade)
// TODO: Single point of contact with the server's REST API.
// TODO: Methods for venues, alternatives, Popular Times, directions, auth, favourites and the heatmap.
