// TODO: LanguageController (control, Observer)
// TODO: Hold the chosen language and provide translated text.
