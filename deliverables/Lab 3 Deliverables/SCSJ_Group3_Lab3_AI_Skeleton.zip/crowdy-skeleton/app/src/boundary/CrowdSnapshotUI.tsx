// TODO: CrowdSnapshotUI (boundary)
// TODO: Show counts of quiet / moderate / busy / closed malls.
// TODO: Show the crowd level near the user and the quietest open mall nearby.
