// TODO: VenueDetailUI (boundary)
// TODO: Show a venue's crowd level, weekly chart, opening hours and alternatives.
// TODO: Save/unsave the venue; open DirectionsUI.
