// TODO: SettingsUI (boundary)
// TODO: Log in, sign up and log out.
// TODO: Choose language (English / Chinese) and toggle dark mode.
