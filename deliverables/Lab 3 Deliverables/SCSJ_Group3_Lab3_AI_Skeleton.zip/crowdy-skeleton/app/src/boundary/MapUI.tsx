// TODO: MapUI (boundary)
// TODO: Show venue pins coloured by crowd level.
// TODO: Toggle the crowd heatmap overlay; recentre on the user's location.
