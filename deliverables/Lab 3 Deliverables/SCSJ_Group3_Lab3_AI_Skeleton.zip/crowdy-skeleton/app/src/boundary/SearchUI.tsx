// TODO: SearchUI (boundary)
// TODO: Text input for searching venues by name, address or postal code.
// TODO: List results from SearchController.
