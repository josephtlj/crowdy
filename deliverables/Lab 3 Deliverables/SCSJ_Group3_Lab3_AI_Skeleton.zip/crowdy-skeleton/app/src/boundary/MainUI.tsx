// TODO: MainUI (boundary)
// TODO: Home screen with Areas, Saved and Search tabs.
// TODO: Hold the active tab, map layer toggles and selected venue.
// TODO: Open VenueDetailUI when a venue is chosen; open SettingsUI from the Settings tab.
