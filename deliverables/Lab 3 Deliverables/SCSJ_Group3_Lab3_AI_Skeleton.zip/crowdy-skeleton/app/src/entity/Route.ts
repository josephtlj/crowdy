// TODO: Route (entity)
// TODO: Attributes: mode, durationSeconds, distanceMeters, transfers; list of RouteSteps.
