// TODO: MapRegion (entity)
// TODO: Attributes: latitude, longitude, latitudeDelta, longitudeDelta.
