// TODO: RouteStep (entity)
// TODO: Attributes: mode, instruction, lineName, stopCount, crowdLevel.
