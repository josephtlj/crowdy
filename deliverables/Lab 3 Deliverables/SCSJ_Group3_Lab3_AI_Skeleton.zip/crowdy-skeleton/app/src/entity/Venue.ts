// TODO: Venue (entity)
// TODO: Attributes: id, name, category, address, postalCode, lat, lng,
// TODO: crowdPercent, crowdLevel, source, lastUpdated, heatmapRadiusM.
