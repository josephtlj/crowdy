// TODO: SavedVenueIds (container)
// TODO: Set of saved venue ids: has, add, remove.
