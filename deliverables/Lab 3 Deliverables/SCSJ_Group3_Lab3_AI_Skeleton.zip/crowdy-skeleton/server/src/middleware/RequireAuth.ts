// TODO: RequireAuth (control)
// TODO: Reject requests without a valid sign-in token; pass on the account id.
