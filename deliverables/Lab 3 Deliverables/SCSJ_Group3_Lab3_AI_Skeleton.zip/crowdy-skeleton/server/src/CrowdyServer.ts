// TODO: CrowdyServer (start-up class)
// TODO: Mount every controller's routes and start PopularTimesScheduler.
// TODO: Shut down cleanly (close browser and database pool).
