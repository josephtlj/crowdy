// TODO: Station (entity)
// TODO: Attributes: code, id, name, mode (MRT/LRT), lat, lng.
