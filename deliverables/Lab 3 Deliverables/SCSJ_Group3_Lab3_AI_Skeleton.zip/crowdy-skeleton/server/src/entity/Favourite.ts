// TODO: Favourite (entity)
// TODO: Attributes: accountId, venueId, createdAt.
