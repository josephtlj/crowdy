// TODO: OpenHours (entity)
// TODO: Attributes: day, open, close. Operation: isOpenAt(time).
