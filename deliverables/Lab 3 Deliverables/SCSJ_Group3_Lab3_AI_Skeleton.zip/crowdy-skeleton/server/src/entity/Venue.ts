// TODO: Venue (entity)
// TODO: See app/src/entity/Venue.ts - same attributes.
