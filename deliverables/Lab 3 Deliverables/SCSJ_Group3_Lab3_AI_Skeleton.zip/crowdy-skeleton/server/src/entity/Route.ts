// TODO: Route (entity)
// TODO: See app/src/entity/Route.ts - same attributes.
