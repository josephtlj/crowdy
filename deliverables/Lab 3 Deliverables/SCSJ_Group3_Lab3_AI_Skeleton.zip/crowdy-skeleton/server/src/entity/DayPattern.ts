// TODO: DayPattern (entity)
// TODO: Attributes: day (0-6), hourly percentages.
