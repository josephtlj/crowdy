// TODO: Account (entity)
// TODO: Attributes: accountId, username, passwordHash, createdAt.
