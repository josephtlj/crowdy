// TODO: PopularTimesPattern (entity)
// TODO: Attributes: venueId, scrapedAt; 7 DayPatterns and up to 7 OpenHours.
// TODO: Operation: currentReading(now).
