// TODO: PopularTimesScheduler (control)
// TODO: Periodically refresh venues whose pattern is out of date.
