// TODO: PopularTimesService (control)
// TODO: Refresh, cache and look up venues' Popular Times patterns; sync with the database.
