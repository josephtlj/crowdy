// TODO: CrowdAggregator (control, Facade)
// TODO: Merge station and mall crowd data into one venue list.
