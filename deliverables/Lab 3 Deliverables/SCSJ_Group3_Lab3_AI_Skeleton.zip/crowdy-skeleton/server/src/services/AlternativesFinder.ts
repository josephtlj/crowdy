// TODO: AlternativesFinder (control)
// TODO: Find quieter venues of the same type nearby.
