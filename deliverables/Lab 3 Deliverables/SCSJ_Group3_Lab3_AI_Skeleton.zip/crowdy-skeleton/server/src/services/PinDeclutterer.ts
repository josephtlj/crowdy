// TODO: PinDeclutterer (control)
// TODO: Spread apart venues whose map pins overlap.
