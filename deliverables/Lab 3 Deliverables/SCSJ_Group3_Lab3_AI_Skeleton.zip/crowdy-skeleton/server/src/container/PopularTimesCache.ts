// TODO: PopularTimesCache (container)
// TODO: Map of venue id to PopularTimesPattern: get, record.
