// TODO: AuthController (control)
// TODO: Sign up and log in; hash passwords and issue sign-in tokens.
