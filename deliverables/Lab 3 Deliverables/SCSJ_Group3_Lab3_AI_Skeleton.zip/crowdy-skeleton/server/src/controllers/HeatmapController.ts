// TODO: HeatmapController (control)
// TODO: GET the heatmap image and its geographic bounds.
