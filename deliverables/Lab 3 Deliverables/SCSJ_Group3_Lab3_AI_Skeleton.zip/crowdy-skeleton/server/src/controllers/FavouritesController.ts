// TODO: FavouritesController (control)
// TODO: List, save, remove and merge an account's favourites (requires sign-in).
