// TODO: DatabasePool (Singleton)
// TODO: Shared database connection pool.
