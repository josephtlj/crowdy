// TODO: LtaClient (Adapter)
// TODO: Fetch station crowd levels and carpark lots from LTA DataMall.
