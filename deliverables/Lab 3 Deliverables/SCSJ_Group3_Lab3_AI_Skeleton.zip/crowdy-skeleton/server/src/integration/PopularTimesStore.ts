// TODO: PopularTimesStore (Repository)
// TODO: Load and save Popular Times patterns in the database.
