// TODO: GoogleMapsScraper (Adapter)
// TODO: Read a venue's Popular Times from Google Maps.
