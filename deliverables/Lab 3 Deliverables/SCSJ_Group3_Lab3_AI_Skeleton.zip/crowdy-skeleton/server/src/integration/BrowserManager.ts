// TODO: BrowserManager (Singleton)
// TODO: Provide one shared headless browser.
