import { Venue } from "../types/venue";
import { haversineKm } from "./distance";

// AlternativesFinder - control class for ViewAlternatives (#3-2), which
// extends ViewVenueDetail (#3-1). Suggests quieter venues of the same
// category close to the one being viewed.
const MAX_DISTANCE_KM = 3;
const MAX_RESULTS = 3;
// Haversine maths carries a little floating-point error (a venue exactly
// 3km away can come out as 3.000000000000002km), so the 3km limit allows
// for it. 1e-9km is far below any real distance difference.
const DISTANCE_EPSILON_KM = 1e-9;

// A Closed venue reads 0% and an Unavailable one has no reading at all, so
// neither is genuinely "less crowded" - both are left out as alternatives.
function hasLiveReading(venue: Venue): boolean {
  return venue.crowdLevel !== "Closed" && venue.crowdLevel !== "Unavailable";
}

/**
 * Finds lower-crowd venues of the same category near the venue being viewed.
 * Transit venues are excluded from alternatives matching.
 * @param venue - the venue being viewed
 * @param all - every venue to choose from (may include the viewed venue itself)
 * @returns up to three alternatives within 3km with a lower crowd percentage,
 *   nearest first, each with its distanceKm from the viewed venue (empty if
 *   none qualify)
 */
export function findAlternatives(venue: Venue, all: Venue[]): Venue[] {
  if (venue.category === "Transit") return [];

  return all
    .filter(
      (other) =>
        other.id !== venue.id &&
        other.category === venue.category &&
        hasLiveReading(other) &&
        other.crowdPercent < venue.crowdPercent
    )
    .map((other) => ({
      ...other,
      distanceKm: haversineKm(venue.lat, venue.lng, other.lat, other.lng),
    }))
    .filter((other) => other.distanceKm <= MAX_DISTANCE_KM + DISTANCE_EPSILON_KM)
    .sort((a, b) => a.distanceKm - b.distanceKm)
    .slice(0, MAX_RESULTS);
}
